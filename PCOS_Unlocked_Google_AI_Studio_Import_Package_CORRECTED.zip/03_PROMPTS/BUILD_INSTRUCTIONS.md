# How to use this package in Google AI Studio

## Important: this is a build specification, not a runnable website

This package contains the PCOS Unlocked project dossier, route/content/design configuration, research notes, prompts and SVG assets. It does **not** contain a generated React application. In particular, it intentionally has no `package.json`, lockfile, `src/` directory or `index.html`.

Do not import this package as if it were an existing Node.js website and then ask Google AI Studio to run it. There are no application dependencies to install yet, so a dependency-installation error is expected if the environment treats this folder as a runnable app.

## Recommended workflow

1. Extract this ZIP.
2. Create a new GitHub repository named `pcos-unlocked`.
3. Upload the **contents** of the extracted folder to the repository root (so `README.md`, `01_PROJECT_BRIEF/`, `02_JSON_CONFIG/`, etc. are directly visible at the root; do not upload the ZIP itself or nest the whole folder one level deeper).
4. Open Google AI Studio and start a fresh app/build workspace that generates a new frontend. Do not try to run the specification repository as the finished app.
5. Provide these files to the build context:
   - `01_PROJECT_BRIEF/PCOS_Unlocked_Complete_Project_Dossier.md`
   - every JSON file in `02_JSON_CONFIG/`
   - `05_ASSETS/diagrams/` SVG files
   - `03_PROMPTS/GOOGLE_AI_STUDIO_MASTER_PROMPT.md`
6. Paste the complete master prompt and ask AI Studio to generate the application.
7. Ask it to create a real React + TypeScript + Vite application, including `package.json`, a lockfile, `index.html`, `src/`, and build/start scripts. It must implement all 29 routes in `02_JSON_CONFIG/routes.json`.
8. Only after those application files exist, install dependencies and run the app. Keep `package.json` and the lockfile in sync; use the package manager and lockfile generated for the project.
9. Test direct loading and refresh on nested routes, browser navigation, responsive layouts, keyboard access, diagrams, quiz, print view and 404 behaviour.
10. Review clinical content, source links, privacy and accessibility before deployment.

## Dependency/version guidance

No dependency versions are specified in this source package because no frontend implementation or dependency manifest is included. Do not invent versions in this specification bundle. Let the generated React/Vite application establish its dependencies, then retain the exact compatible versions in `package.json` and the matching lockfile. If an existing generated application is available, diagnose its own `package.json` and lockfile rather than replacing them with arbitrary versions.

## Medical and research safeguards

This is an educational resource, not a diagnostic tool. Do not add symptom checkers, diagnosis scores, medication dosing or cure claims. Do not collect sensitive health information. The supplied datasets are exploratory and have limitations; do not use them to claim Indian prevalence or compare male/female awareness. Use actual response exports for charts. Qualified clinical review is required before public launch.
