# PCOS Unlocked — Google AI Studio Build Package

**Tagline:** Understand your body. Question the myths. Find your way forward.

> **Important:** This is a project specification and asset bundle, not a runnable website. It does not include a React application, `package.json`, lockfile, `src/` directory or `index.html`. Google AI Studio must generate those application files from the supplied brief and prompt before dependency installation or running can succeed.

## What's included
- `01_PROJECT_BRIEF/` — project dossier, audience, information architecture, routes, page requirements and QA guidance.
- `02_JSON_CONFIG/` — project, content, route, design-system and interaction configuration.
- `03_PROMPTS/` — Google AI Studio master prompt and build instructions.
- `04_RESEARCH/` — research limitations and source register.
- `05_ASSETS/diagrams/` — five original SVG educational diagrams.
- `06_GITHUB_SETUP/` — GitHub import checklist.

## Correct workflow
1. Extract this ZIP.
2. Upload the **contents** of the extracted folder to the root of a GitHub repository (not the ZIP and not a nested wrapper folder).
3. Use the repository as source material/context for a fresh Google AI Studio app build.
4. Follow `03_PROMPTS/BUILD_INSTRUCTIONS.md` and provide the dossier, JSON configuration, SVG assets and master prompt.
5. Have AI Studio generate the actual React + TypeScript + Vite application. Only then install dependencies and run it.

## Validation performed on this package
- All 7 JSON files parse successfully.
- All 5 SVG diagrams parse successfully.
- `02_JSON_CONFIG/routes.json` contains 29 routes.
- No frontend source code or dependency manifest is present; therefore no dependency versions or application build can be verified from this package alone.

## Medical and research safeguards
PCOS Unlocked is an educational resource, not a diagnostic tool. Do not add symptom checkers, diagnosis scores, medication dosing or cure claims. Do not collect sensitive health information. Do not claim Indian prevalence from the supplied exploratory datasets. Verify sources and obtain qualified clinical review before public launch.
